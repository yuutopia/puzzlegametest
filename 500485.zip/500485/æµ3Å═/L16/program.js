function oshita() {
    youso=document.getElementById('text01');
    t=youso.value;
    alert(t);
}