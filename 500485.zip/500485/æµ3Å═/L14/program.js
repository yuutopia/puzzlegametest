function oshita() {
    alert('こんにちは');
}