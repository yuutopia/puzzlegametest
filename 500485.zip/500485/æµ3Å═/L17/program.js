function oshita() {
    youso=document.getElementById('text01');
    t=youso.value;

    hyouji='こんにちは'+t+'さん';
    alert(hyouji);
}