function keisan() {
	text01 = document.getElementById('atai1');
	text02 = document.getElementById('atai2');

	x = parseInt(text01.value);
	y = parseInt(text02.value);

	z = x + y;
	alert(z);
}