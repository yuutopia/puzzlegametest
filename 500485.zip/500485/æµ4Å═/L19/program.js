function keisan() {
	alert(1 + 2 + 3 * 4 / 2);
}